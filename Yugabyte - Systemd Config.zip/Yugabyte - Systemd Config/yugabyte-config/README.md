Role Name
=========

Yb_Config

Requirements
------------

If you are going to run this in Visual Studio Code,

Perquisites: Extensions: Ansible,Yaml


Role Variables
--------------

vars/main.yml :

Make sure to add your YB_instances Private IPs in "yugabyte_masters" Variable.


Author Information
------------------

Team: Managed IT
Company: Justo_Global
